function [secKey] = GetSecKey()
    secKey = '';
end

